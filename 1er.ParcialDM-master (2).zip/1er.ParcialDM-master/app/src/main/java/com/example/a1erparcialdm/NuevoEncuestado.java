package com.example.a1erparcialdm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class NuevoEncuestado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_encuestado);
    }

    public void btnListaAlimentos_click(View v){
        //Inicializa la activty de descarga
        Intent frmListadoAlimentos2 = new Intent(this, ListadoAlimentos.class);
        startActivity(frmListadoAlimentos2);
    }

    public void btnRegresar_click(View v){
        finish();
    }
}